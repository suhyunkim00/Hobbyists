package model.service;

public class ExistingClassException extends Exception {
	private static final long serialVersionUID = 1L;

	public ExistingClassException() {
		super();
	}

	public ExistingClassException(String arg0) {
		super(arg0);
	}
}