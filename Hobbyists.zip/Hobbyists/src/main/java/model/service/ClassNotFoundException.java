package model.service;

public class ClassNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;

	public ClassNotFoundException() {
		super();
	}

	public ClassNotFoundException(String arg0) {
		super(arg0);
	}
}